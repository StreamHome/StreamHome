"""Protected, generation-bound recovery grants for the original operation."""
from __future__ import annotations

from dataclasses import replace
from pathlib import Path
import math
import time

from .. import management_journal as contract, management_recovery_store as recovery, management_store, state
from ..execution_state import read_active_execution
from .requests import ManagementRequest, REQUEST_ROOT, parse_management_request
from . import requests as request_contract
from .rpc import ControlError
from .tickets import read_protected_json, read_stop_epoch

ROOT = Path('/opt/streamhome')


def recovery_path(operation_id: str, generation: int):
    contract._uuid(operation_id, 'recovery operation')
    contract._integer(generation, 2, 'recovery generation')
    return REQUEST_ROOT / operation_id / f'recovery-{generation}.json'


def parse_grant(payload: dict) -> dict:
    if isinstance(payload,dict) and type(payload.get('schema_version')) is int and payload['schema_version']==5:
        return _parse_control_maintenance_grant(payload)
    if isinstance(payload, dict) and type(payload.get('schema_version')) is int and payload['schema_version'] == 4:
        return _parse_maintenance_grant(payload)
    fields = {'schema_version', 'recovery_review_id', 'source_evidence_sha256', 'source_request_sha256', 'action', 'request', 'expires_at_monotonic'}
    scoped = isinstance(payload, dict) and type(payload.get('schema_version')) is int and payload['schema_version'] in {2, 3}
    resuming = scoped and payload['schema_version'] == 3
    if scoped:
        fields.add('issuer_scope')
    if resuming:
        fields.add('resumption_plan_id')
    if (not isinstance(payload, dict) or set(payload) != fields
            or type(payload['schema_version']) is not int or payload['schema_version'] not in {1, 2, 3}
            or not isinstance(payload['action'], str) or payload['action'] not in recovery.ACTIONS):
        raise ControlError('control_recovery_request_invalid')
    expiry = payload['expires_at_monotonic']
    if type(expiry) not in {int, float} or not math.isfinite(expiry) or not 0 < expiry < 10**12:
        raise ControlError('control_recovery_request_invalid')
    contract._uuid(payload['recovery_review_id'], 'recovery review')
    for name in ('source_evidence_sha256', 'source_request_sha256'):
        contract._text(payload[name], contract._SHA256, name)
    current = parse_management_request(payload['request'])
    if (current.action is contract.ManagementAction.PROVISION_CONTROL
            and current.activation_mode is contract.ActivationMode.CUTOVER
            and payload['schema_version'] != (3 if current.initial_service_state=='running' else 2)):
        raise ControlError('control_recovery_request_invalid')
    if scoped:
        from .stopped_repair import parse_scope
        parse_scope(payload['issuer_scope'], current.installation_id)
        if (not resuming and current.initial_service_state != 'stopped'
                or resuming and (current.initial_service_state != 'running'
                    or current.activation_mode is not contract.ActivationMode.CUTOVER)):
            raise ControlError('control_recovery_request_invalid')
    if resuming:
        contract._uuid(payload['resumption_plan_id'], 'resumption plan')
    original = request_contract.read_management_request(current.operation_id)
    if (original.sha256 != payload['source_request_sha256']
            or resuming and (current.supervisor != original.supervisor or current.backend is not None)):
        raise ControlError('control_recovery_request_changed')
    mutable = {'expected_generation', 'supervisor', 'backend', 'boot_id', 'stop_epoch', 'previous_boot_enabled', 'boot_enabled'}
    before, after = original.payload(), current.payload()
    reversing = payload['action'] in {'rollback', 'safe_abort'}
    stopped_repair = current.initial_service_state == 'stopped' and current.action in {
        contract.ManagementAction.REPAIR_ENVIRONMENT,contract.ManagementAction.PROVISION_CONTROL}
    if (any(before[key] != after[key] for key in before.keys() - mutable)
            or current.expected_generation <= original.expected_generation
            or current.supervisor_invocation_id != original.supervisor_invocation_id
            or current.activation_mode is contract.ActivationMode.CUTOVER and (
                current.initial_service_state != 'running' and not stopped_repair or current.backend is not None
                or current.boot_enabled is not (original.previous_boot_enabled if reversing else current.previous_boot_enabled))
            or current.activation_mode is not contract.ActivationMode.CUTOVER and (
                reversing
                or current.boot_enabled is not original.boot_enabled
                or current.supervisor != original.supervisor or current.backend != original.backend
                or current.initial_service_state == 'running' and current.backend is None)):
        raise ControlError('control_recovery_request_changed')
    return payload


def _parse_control_maintenance_grant(payload: dict) -> dict:
    fields={'schema_version','action','request','source_request_sha256','source_evidence_sha256',
        'recovery_review_id','repair_review_sha256','filesystem_sha256','artifact','selection',
        'issuer_scope','expires_at_monotonic'}
    if set(payload)!=fields or payload['action']!=recovery.CONTROL_MAINTENANCE_ACTION:
        raise ControlError('control_recovery_request_invalid')
    contract._uuid(payload['recovery_review_id'],'control repair review')
    for name in ('source_request_sha256','source_evidence_sha256','repair_review_sha256','filesystem_sha256'):
        contract._text(payload[name],contract._SHA256,name)
    artifact=payload['artifact']
    if not isinstance(artifact,dict) or set(artifact)!={'bundle_id','manifest_sha256','artifact_sha256','entry_sha256'}:
        raise ControlError('control_recovery_request_invalid')
    contract._uuid(artifact['bundle_id'],'bound control')
    for name in ('manifest_sha256','artifact_sha256','entry_sha256'):
        contract._text(artifact[name],contract._SHA256,name)
    selection=payload['selection']
    if (not isinstance(selection,dict) or type(selection.get('schema_version')) is not int
            or selection!={'schema_version':1,'bundle_id':artifact['bundle_id'],'manifest_sha256':artifact['manifest_sha256']}):
        raise ControlError('control_recovery_request_invalid')
    expiry=payload['expires_at_monotonic']
    if type(expiry) not in {int,float} or not math.isfinite(expiry) or not 0<expiry<10**12:
        raise ControlError('control_recovery_request_invalid')
    current=parse_management_request(payload['request'])
    original=request_contract.read_management_request(current.operation_id)
    before,after=original.payload(),current.payload()
    mutable={'expected_generation','backend','boot_id','stop_epoch'}
    if (payload['source_request_sha256']!=original.sha256
            or current.expected_generation<=original.expected_generation or current.backend is not None
            or any(before[name]!=after[name] for name in before.keys()-mutable)):
        raise ControlError('control_recovery_request_changed')
    from .stopped_repair import parse_scope
    parse_scope(payload['issuer_scope'],current.installation_id)
    return payload


def _parse_maintenance_grant(payload: dict) -> dict:
    fields = {'schema_version', 'recovery_review_id', 'source_evidence_sha256', 'source_request_sha256',
        'action', 'request', 'expires_at_monotonic', 'issuer_scope', 'repair_review_sha256',
        'execution_sha256', 'filesystem_sha256'}
    if set(payload) != fields or payload['action'] != recovery.MAINTENANCE_ACTION:
        raise ControlError('control_recovery_request_invalid')
    contract._uuid(payload['recovery_review_id'], 'bound repair review')
    for name in ('source_evidence_sha256', 'source_request_sha256', 'repair_review_sha256', 'execution_sha256', 'filesystem_sha256'):
        contract._text(payload[name], contract._SHA256, name)
    expiry = payload['expires_at_monotonic']
    if type(expiry) not in {int, float} or not math.isfinite(expiry) or not 0 < expiry < 10**12:
        raise ControlError('control_recovery_request_invalid')
    current = parse_management_request(payload['request'])
    original = request_contract.read_management_request(current.operation_id)
    from .stopped_repair import parse_scope
    parse_scope(payload['issuer_scope'], current.installation_id)
    if (current.activation_mode is not contract.ActivationMode.CUTOVER or current.backend is not None
            or original.sha256 != payload['source_request_sha256'] or current.expected_generation <= original.expected_generation
            or any(original.payload()[name] != current.payload()[name] for name in original.payload().keys()
                   - {'expected_generation', 'backend', 'boot_id', 'stop_epoch'})):
        raise ControlError('control_recovery_request_changed')
    return payload


def read_grant(operation_id: str, generation: int, *, require_live: bool = True) -> dict:
    grant = parse_grant(read_protected_json(recovery_path(operation_id, generation)))
    retained = REQUEST_ROOT / operation_id / ('recovery-review-' + grant['recovery_review_id'] + '.json')
    if read_protected_json(retained) != grant:
        raise ControlError('control_recovery_request_changed')
    reviewed = parse_management_request(grant['request'])
    if reviewed.operation_id != operation_id or reviewed.expected_generation + 1 != generation:
        raise ControlError('control_recovery_request_changed')
    if require_live and (time.monotonic() >= grant['expires_at_monotonic'] or reviewed.boot_id != Path('/proc/sys/kernel/random/boot_id').read_text().strip()
            or reviewed.stop_epoch != read_stop_epoch()):
        raise ControlError('control_recovery_permission_expired')
    if require_live and grant['schema_version'] in {2, 3, 4, 5}:
        from .stopped_repair import require_scope
        require_scope(grant['issuer_scope'], reviewed.installation_id)
    if require_live and grant['schema_version'] == 3:
        from .resumption_ticket import reviewed_plan
        record = reviewed_plan(grant['resumption_plan_id'], installation_id=reviewed.installation_id,
            control_manifest_sha256=reviewed.controller_control_manifest_sha256)
        plan = record['plan']
        if (plan['operation_id'] != operation_id or plan['generation'] != generation
                or plan['review_id'] != grant['recovery_review_id'] or plan['owner_type'] != 'management'
                or plan['action'] != reviewed.action.value or record['issuer']['scope'] != grant['issuer_scope']):
            raise ControlError('control_resumption_review_changed')
    return grant


def effective_request(journal: contract.ManagementJournal, *, original: ManagementRequest | None = None, require_live: bool = True) -> ManagementRequest:
    original = request_contract.read_management_request(journal.operation_id) if original is None else original
    if journal.generation == original.expected_generation + 1:
        return original
    grant = read_grant(journal.operation_id, journal.generation, require_live=require_live)
    intent = recovery.inspect_takeover(ROOT, journal.operation_id, journal.generation)
    if (intent.review_id != grant['recovery_review_id'] or intent.action != grant['action']
            or intent.target_journal.generation != journal.generation
            or intent.target_journal.acceptance is not None and intent.target_journal.acceptance != journal.acceptance):
        raise ControlError('control_recovery_request_changed')
    initial = replace(journal, stage=contract.ManagementStage.RECOVERY_REQUIRED, acceptance=intent.target_journal.acceptance)
    if initial != intent.target_journal:
        raise ControlError('control_recovery_request_changed')
    return parse_management_request(grant['request'])


def review(operation_id: str, *, control_manifest_sha256: str) -> dict:
    root = ROOT
    original = request_contract.read_management_request(operation_id)
    authority = state.inspect_state(root)
    plan = recovery.inspect_recovery(root, operation_id, authority.generation)
    journal = management_store.inspect_management_journal(root, operation_id)
    if (original.activation_mode is contract.ActivationMode.CUTOVER and original.initial_service_state != 'running'
            and original.action not in {contract.ManagementAction.REPAIR_ENVIRONMENT,contract.ManagementAction.PROVISION_CONTROL}
            or original.previous != journal.previous or original.candidate != journal.candidate
            or original.review_id != journal.review_id
            or original.action is not journal.action or original.activation_mode is not journal.activation_mode
            or original.installation_id != journal.installation_id
            or original.initial_service_state != journal.initial_service_state
            or original.supervisor_invocation_id != journal.supervisor_invocation_id
            or original.controller_control_manifest_sha256 != control_manifest_sha256):
        raise ControlError('control_recovery_mode_unavailable')
    active = read_active_execution(root)
    effective, _ = recovery._effective_journal(root, authority, journal)
    selected = contract.selected_execution(effective)
    if (active.installation_id != journal.installation_id
            or active.execution not in {journal.previous, journal.candidate}
            or journal.acceptance is None and active.execution != journal.previous
            or effective.recovery_target == 'previous' and active.execution != selected):
        raise ControlError('control_recovery_execution_changed')
    result = {**plan, 'installation_id': journal.installation_id,
            'management_action': original.action.value,
            'previous_execution_sha256': contract.execution_tuple_sha256(journal.previous),
            'candidate_execution_sha256': contract.execution_tuple_sha256(journal.candidate),
            'selected_execution_sha256': contract.execution_tuple_sha256(selected),
            'activation_mode': original.activation_mode.value,
            'initial_service_state': original.initial_service_state,
            'boot_enabled': original.boot_enabled,
            'previous_boot_enabled': original.previous_boot_enabled,
            'recovery_target': effective.recovery_target,
            'supervisor_invocation_id': original.supervisor_invocation_id,
            'source_request_sha256': original.sha256,
            'control_manifest_sha256': control_manifest_sha256}
    if journal.action is contract.ManagementAction.PROVISION_CONTROL and journal.activation_mode is contract.ActivationMode.CUTOVER:
        result.update(previous_control_manifest_sha256=journal.previous.control_manifest_sha256,
            selected_control_manifest_sha256=selected.control_manifest_sha256)
    return result


def prepare(payload: dict, *, control_manifest_sha256: str) -> dict:
    from .requests import _process
    fields = {'operation_id', 'expected_evidence_sha256', 'recovery_review_id', 'processes', 'boot_enabled', 'boot_id', 'stop_epoch'}
    resuming = isinstance(payload, dict) and 'resumption_plan_id' in payload
    if resuming:
        fields |= {'issuer_scope', 'resumption_plan_id'}
    if (not isinstance(payload, dict) or set(payload) not in (fields, fields | {'action'}, fields | {'issuer_scope'}, fields | {'action', 'issuer_scope'})
            or type(payload['boot_enabled']) is not bool):
        raise ControlError('control_recovery_request_invalid')
    snapshot = review(payload['operation_id'], control_manifest_sha256=control_manifest_sha256)
    processes = payload['processes']
    action = payload.get('action', 'continue_recovery')
    if (action not in snapshot.get('permitted_actions', ['continue_recovery'])
            or snapshot['evidence_sha256'] != payload['expected_evidence_sha256']
            or not isinstance(processes, dict) or set(processes) != {'initial_service_state', 'supervisor_invocation_id', 'supervisor', 'backend'}
            or (not resuming and (processes['initial_service_state'] != snapshot['initial_service_state']
                or processes['supervisor_invocation_id'] != snapshot['supervisor_invocation_id']))
            or resuming and (snapshot['initial_service_state'] != 'running' or snapshot['activation_mode'] != 'cutover'
                or processes != {'initial_service_state': 'stopped', 'supervisor_invocation_id': None, 'supervisor': None, 'backend': None})):
        raise ControlError('control_recovery_review_stale')
    original = request_contract.read_management_request(payload['operation_id'])
    issuer_scope = payload.get('issuer_scope')
    if original.initial_service_state == 'stopped' or resuming:
        from .stopped_repair import require_scope
        require_scope(issuer_scope, original.installation_id)
    elif issuer_scope is not None:
        raise ControlError('control_recovery_request_invalid')
    if action in {'rollback', 'safe_abort'} or snapshot.get('recovery_target') == 'previous':
        from .reader_support import require_previous_reader
        require_previous_reader(original.previous)
    if resuming:
        from .reader_support import require_resumption_reader
        require_resumption_reader(original.previous if action in {'rollback', 'safe_abort'}
            or snapshot.get('recovery_target') == 'previous' else original.candidate)
    preserving = original.activation_mode is not contract.ActivationMode.CUTOVER
    target_boot = (original.previous_boot_enabled if action in {'rollback', 'safe_abort'}
                   else original.boot_enabled if preserving else payload['boot_enabled'])
    current = replace(original, expected_generation=snapshot['generation'], supervisor=original.supervisor if resuming else _process(processes['supervisor']),
                      backend=_process(processes['backend']) if preserving else None,
                      previous_boot_enabled=payload['boot_enabled'], boot_enabled=target_boot,
                      boot_id=payload['boot_id'], stop_epoch=payload['stop_epoch'])
    value = {'schema_version': 1, 'recovery_review_id': payload['recovery_review_id'],
             'source_evidence_sha256': snapshot['evidence_sha256'], 'source_request_sha256': original.sha256,
             'action': action, 'request': current.payload(), 'expires_at_monotonic': time.monotonic() + 900}
    if issuer_scope is not None:
        value.update(schema_version=2, issuer_scope=issuer_scope)
    if resuming:
        value.update(schema_version=3, resumption_plan_id=payload['resumption_plan_id'])
    return parse_grant(value)
